🔥 FASTSCAN TOOL 🔥
Fast | Simple | Powerful Host Scanner

Author: hosthunter
Language: Python
Platform: Termux / Linux

📌 Features:
- Fast host scanning
- Simple & beginner friendly
- Lightweight & powerful
- Clean CLI interface

📥 Installation (Termux):

pkg update -y && pkg upgrade -y
pkg install python git -y
pip install git+https://github.com/rehanz4x/fastscan.git

▶️ Run Tool:
python -m fastscan
