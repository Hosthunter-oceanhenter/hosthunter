from setuptools import setup

setup(
    name="hosthunter",
    version="1.0",
    scripts=["hosthunter.py"],
)